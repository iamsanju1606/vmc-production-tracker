#!/usr/bin/env bash
set -e
echo "Installing dependencies (if needed)..."
npm install
echo "Starting VMC Production Full-Stack Server at http://localhost:3000 ..."
node server.js
