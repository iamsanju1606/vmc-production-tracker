const express = require('express');
const path = require('path');
const ExcelJS = require('exceljs');
const {
  initDatabase,
  getGroupedEntries,
  insertBatch,
  deleteGroup,
  getSuggestions
} = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Get all saved machine groups & job rows
app.get('/api/entries', (req, res) => {
  try {
    const { date = '', search = '' } = req.query;
    const entries = getGroupedEntries({ date, search });
    res.json({ ok: true, entries });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Failed to load production entries' });
  }
});

// Save multiple machines + their part rows in one batch
app.post('/api/entries/batch', (req, res) => {
  try {
    const { entries } = req.body;
    if (!Array.isArray(entries) || entries.length === 0) {
      return res.status(400).json({ ok: false, error: 'At least one machine entry is required.' });
    }

    for (const entry of entries) {
      if (!entry.date || !entry.machine || !entry.employee) {
        return res.status(400).json({ ok: false, error: 'Date, Machine No, and Employee Name are required for every machine.' });
      }
      if (!Array.isArray(entry.jobs) || entry.jobs.length === 0) {
        return res.status(400).json({ ok: false, error: `At least one part row is required for ${entry.machine}.` });
      }
      for (const job of entry.jobs) {
        if (!job.description || !job.partNo) {
          return res.status(400).json({ ok: false, error: `Part Description and Part No are required for ${entry.machine}.` });
        }
      }
    }

    insertBatch(entries);
    res.json({ ok: true, savedCount: entries.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Failed to save production batch.' });
  }
});

// Delete a machine group
app.delete('/api/entries/:id', (req, res) => {
  try {
    deleteGroup(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Failed to delete machine group.' });
  }
});

// Autocomplete suggestions from DB history
app.get('/api/suggestions', (req, res) => {
  try {
    res.json({ ok: true, ...getSuggestions() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Failed to load suggestions.' });
  }
});

// Export formatted Excel with merged Date, Machine, Employee per machine group
app.get('/api/export/excel', async (req, res) => {
  try {
    const { date = '', search = '' } = req.query;
    const entries = getGroupedEntries({ date, search });

    const wb = new ExcelJS.Workbook();
    wb.creator = 'VMC Production Tracker';
    wb.created = new Date();

    const ws = wb.addWorksheet('Production', {
      views: [{ state: 'frozen', ySplit: 1 }]
    });

    const headers = [
      'Date',
      'Machine',
      'Employee',
      'Shift',
      'Part Description',
      'Part No',
      'Start Time',
      'End Time',
      'OK Qty',
      'Operation',
      'Other Remark'
    ];

    const headerRow = ws.addRow(headers);
    headerRow.height = 24;
    headerRow.eachCell((cell) => {
      cell.font = { name: 'Calibri', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
        bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
        left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
        right: { style: 'thin', color: { argb: 'FFCBD5E1' } }
      };
    });

    // Sort chronologically (oldest date first, then insertion order) so Machine #1, #2, #3 stay in exact entry order
    const orderedEntries = entries.slice().sort((a, b) => {
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      return (a.createdAt || '').localeCompare(b.createdAt || '');
    });

    orderedEntries.forEach((group, groupIdx) => {
      const startRowNum = ws.rowCount + 1;
      const isAltGroup = groupIdx % 2 === 1;

      group.jobs.forEach((job, jobIdx) => {
        const row = ws.addRow([
          jobIdx === 0 ? group.date : null,
          jobIdx === 0 ? group.machine : null,
          jobIdx === 0 ? group.employee : null,
          job.shift || '',
          job.description,
          job.partNo,
          job.start || '',
          job.end || '',
          Number(job.qty || 0),
          job.operation || '',
          job.remark || ''
        ]);

        row.height = 21;
        row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
          cell.font = {
            name: 'Calibri',
            size: 11,
            bold: colNumber <= 3
          };
          cell.alignment = {
            horizontal: colNumber === 5 || colNumber === 11 ? 'left' : 'center',
            vertical: 'middle',
            wrapText: true
          };
          if (isAltGroup) {
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } };
          }
          cell.border = {
            top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
            bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
            left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
            right: { style: 'thin', color: { argb: 'FFCBD5E1' } }
          };
        });
      });

      const endRowNum = ws.rowCount;
      if (endRowNum > startRowNum) {
        // Merge Date (Col 1), Machine (Col 2), Employee (Col 3) vertically across all rows of this machine
        ws.mergeCells(startRowNum, 1, endRowNum, 1);
        ws.mergeCells(startRowNum, 2, endRowNum, 2);
        ws.mergeCells(startRowNum, 3, endRowNum, 3);
      }
    });

    ws.columns = [
      { width: 14 }, // Date
      { width: 15 }, // Machine
      { width: 18 }, // Employee
      { width: 10 }, // Shift
      { width: 26 }, // Part Description
      { width: 20 }, // Part No
      { width: 14 }, // Start Time
      { width: 14 }, // End Time
      { width: 11 }, // OK Qty
      { width: 16 }, // Operation
      { width: 28 }  // Other Remark
    ];

    if (ws.rowCount > 1) {
      ws.autoFilter = { from: 'A1', to: `K${ws.rowCount}` };
    }

    const fileDate = date || new Date().toISOString().slice(0, 10);
    const filename = `VMC_Production_Master_${fileDate}.xlsx`;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    await wb.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'Failed to generate Excel file.' });
  }
});

initDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`VMC Production Full-Stack Server running at http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Database initialization failed:', err);
    process.exit(1);
  });
