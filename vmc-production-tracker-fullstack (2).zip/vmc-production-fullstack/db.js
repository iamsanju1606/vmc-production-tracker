const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'vmc_production.sqlite');

let db = null;

function saveDatabase() {
  if (!db) return;
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

async function initDatabase() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  db.run(`
    CREATE TABLE IF NOT EXISTS machine_groups (
      id TEXT PRIMARY KEY,
      production_date TEXT NOT NULL,
      machine_no TEXT NOT NULL,
      employee_name TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS job_rows (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      group_id TEXT NOT NULL,
      row_order INTEGER NOT NULL,
      shift TEXT DEFAULT '1',
      part_description TEXT NOT NULL,
      part_no TEXT NOT NULL,
      start_time TEXT DEFAULT '',
      end_time TEXT DEFAULT '',
      ok_qty INTEGER DEFAULT 0,
      operation TEXT DEFAULT '',
      other_remark TEXT DEFAULT '',
      FOREIGN KEY (group_id) REFERENCES machine_groups(id) ON DELETE CASCADE
    );
  `);

  saveDatabase();
  return db;
}

function queryAll(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

function runSql(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  stmt.step();
  stmt.free();
}

function getGroupedEntries({ date = '', search = '' } = {}) {
  let sql = `SELECT * FROM machine_groups`;
  const conditions = [];
  const params = [];

  if (date) {
    conditions.push(`production_date = ?`);
    params.push(date);
  }
  if (conditions.length > 0) {
    sql += ` WHERE ` + conditions.join(' AND ');
  }
  sql += ` ORDER BY production_date DESC, created_at ASC`;

  const groups = queryAll(sql, params);
  const result = [];

  for (const g of groups) {
    const jobs = queryAll(
      `SELECT id, row_order, shift, part_description, part_no, start_time, end_time, ok_qty, operation, other_remark
       FROM job_rows WHERE group_id = ? ORDER BY row_order ASC`,
      [g.id]
    );

    const mapped = {
      id: g.id,
      date: g.production_date,
      machine: g.machine_no,
      employee: g.employee_name,
      createdAt: g.created_at,
      jobs: jobs.map(j => ({
        id: j.id,
        shift: j.shift || '',
        description: j.part_description,
        partNo: j.part_no,
        start: j.start_time || '',
        end: j.end_time || '',
        qty: j.ok_qty ?? 0,
        operation: j.operation || '',
        remark: j.other_remark || ''
      }))
    };

    if (search) {
      const q = search.toLowerCase();
      const haystack = JSON.stringify(mapped).toLowerCase();
      if (!haystack.includes(q)) continue;
    }

    result.push(mapped);
  }

  return result;
}

function insertBatch(entries) {
  db.run('BEGIN TRANSACTION;');
  try {
    for (const entry of entries) {
      const groupId = entry.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const createdAt = entry.createdAt || new Date().toISOString();

      runSql(
        `INSERT INTO machine_groups (id, production_date, machine_no, employee_name, created_at)
         VALUES (?, ?, ?, ?, ?)`,
        [groupId, entry.date, entry.machine, entry.employee, createdAt]
      );

      entry.jobs.forEach((job, index) => {
        runSql(
          `INSERT INTO job_rows (group_id, row_order, shift, part_description, part_no, start_time, end_time, ok_qty, operation, other_remark)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            groupId,
            index + 1,
            String(job.shift ?? entry.shift ?? '1'),
            String(job.description || ''),
            String(job.partNo || ''),
            String(job.start || ''),
            String(job.end || ''),
            Number(job.qty || 0),
            String(job.operation || ''),
            String(job.remark || '')
          ]
        );
      });
    }
    db.run('COMMIT;');
    saveDatabase();
  } catch (err) {
    db.run('ROLLBACK;');
    throw err;
  }
}

function deleteGroup(groupId) {
  db.run('BEGIN TRANSACTION;');
  try {
    runSql(`DELETE FROM job_rows WHERE group_id = ?`, [groupId]);
    runSql(`DELETE FROM machine_groups WHERE id = ?`, [groupId]);
    db.run('COMMIT;');
    saveDatabase();
  } catch (err) {
    db.run('ROLLBACK;');
    throw err;
  }
}

function getSuggestions() {
  const machines = queryAll(`SELECT DISTINCT machine_no FROM machine_groups WHERE machine_no != '' ORDER BY machine_no`).map(r => r.machine_no);
  const employees = queryAll(`SELECT DISTINCT employee_name FROM machine_groups WHERE employee_name != '' ORDER BY employee_name`).map(r => r.employee_name);
  const parts = queryAll(`SELECT DISTINCT part_description FROM job_rows WHERE part_description != '' ORDER BY part_description`).map(r => r.part_description);
  const partNos = queryAll(`SELECT DISTINCT part_no FROM job_rows WHERE part_no != '' ORDER BY part_no`).map(r => r.part_no);
  const operations = queryAll(`SELECT DISTINCT operation FROM job_rows WHERE operation != '' ORDER BY operation`).map(r => r.operation);

  return { machines, employees, parts, partNos, operations };
}

module.exports = {
  initDatabase,
  getGroupedEntries,
  insertBatch,
  deleteGroup,
  getSuggestions
};
