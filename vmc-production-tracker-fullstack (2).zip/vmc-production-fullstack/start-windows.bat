@echo off
echo Installing dependencies (if needed)...
call npm install
echo Starting VMC Production Full-Stack Server at http://localhost:3000 ...
start http://localhost:3000
node server.js
pause
