# VMC Production Master — Full-Stack Web App

Full-stack VMC production tracking web application with:
- **Multi-Machine Batch Entry**: Click **+ Add Machine** to add as many machines as needed (`VMC 1`–`VMC 40` or custom), and **+ Add Part / Row** inside each machine for multiple jobs/operations.
- **Persistent SQLite Backend (`Node.js + Express + sql.js`)**: Saves all production groups and part rows permanently in `data/vmc_production.sqlite` with automatic autocomplete history.
- **Grouped Excel Export (`ExcelJS`)**: Downloads `VMC_Production_Master_YYYY-MM-DD.xlsx` where **Date**, **Machine**, and **Employee** appear **once (merged vertically)** per machine group, while **Shift**, **Part Description**, **Part No**, **Start Time**, **End Time**, **OK Qty**, **Operation**, and **Other Remark** save on each subsequent row.

## Quick Start

1. Install Node.js (v18+ recommended).
2. Open a terminal inside this folder and run:
   ```bash
   npm install
   npm start
   ```
3. Open your browser to:
   ```
   http://localhost:3000
   ```
