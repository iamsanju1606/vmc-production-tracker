import React, { useEffect, useMemo, useState } from 'react';
import { Activity, ClipboardList, Download, FileBarChart, LogOut, Plus, Search, Trash2, Pencil, RefreshCw, Boxes, Users, CalendarDays, CheckCircle2 } from 'lucide-react';

const API = (import.meta.env.VITE_API_URL || '/api').replace(/\/$/,'');
const emptyJob = () => ({ partDescription:'', partNumber:'', startTime:'08:00', endTime:'17:00', okQty:0, operation:'', otherRemark:'' });
const today = () => new Date().toLocaleDateString('en-CA');
const blank = () => ({ date:today(), machine:'', employee:'', shift:'1st Shift', jobs:[emptyJob()] });
function App() {
  const [token,setToken] = useState(localStorage.getItem('vmc_token') || '');
  const [username,setUsername] = useState(localStorage.getItem('vmc_user') || '');
  const [login,setLogin] = useState({username:'admin',password:''});
  const [page,setPage] = useState('Dashboard');
  const [form,setForm] = useState(blank());
  const [editing,setEditing] = useState(null);
  const [records,setRecords] = useState([]);
  const [stats,setStats] = useState({});
  const [suggestions,setSuggestions] = useState({machines:[],employees:[],partDescriptions:[],partNumbers:[]});
  const [filters,setFilters] = useState({search:'',machine:'',employee:'',shift:'',from:'',to:''});
  const [notice,setNotice] = useState('');
  const [busy,setBusy] = useState(false);
  const headers = { 'Content-Type':'application/json', Authorization:`Bearer ${token}` };
  const request = async (path,opts={}) => {
    const r = await fetch(API+path,{...opts,headers:{...headers,...opts.headers}});
    if (r.status===401) { logout(); throw new Error('Session expired. Please login again.'); }
    if (!r.ok) { const d=await r.json().catch(()=>({})); throw new Error(d.message || 'Request failed'); }
    return r;
  };
  const load = async () => {
    try {
      const [r,s,d] = await Promise.all([
        request('/productions'),request('/suggestions'),request('/dashboard')
      ]);
      setRecords(await r.json()); setSuggestions(await s.json()); setStats(await d.json());
    } catch(e) { setNotice(e.message); }
  };
  useEffect(()=>{ if(token) load(); },[token]);
  const logout = () => { localStorage.removeItem('vmc_token');localStorage.removeItem('vmc_user');setToken('');setUsername(''); };
  const doLogin = async e => {
    e.preventDefault(); setBusy(true);setNotice('');
    try {
      const r=await fetch(API+'/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(login)});
      const d=await r.json(); if(!r.ok) throw new Error(d.message || 'Login failed');
      localStorage.setItem('vmc_token',d.token);localStorage.setItem('vmc_user',d.username);setUsername(d.username);setToken(d.token);
    } catch(e){setNotice(e.message);} finally{setBusy(false);}
  };
  const setGroup = (k,v) => setForm(f=>({...f,[k]:v}));
  const setJob = (i,k,v) => setForm(f=>({...f,jobs:f.jobs.map((j,n)=>n===i?{...j,[k]:v}:j)}));
  const save = async e => {
    e.preventDefault();setBusy(true);setNotice('');
    try {
      const path=editing?`/productions/${editing}`:'/productions';
      await request(path,{method:editing?'PUT':'POST',body:JSON.stringify(form)});
      setNotice(editing?'Production updated successfully':'Production saved successfully');
      setForm(blank());setEditing(null);setPage('Production History');await load();
    } catch(e){setNotice(e.message);} finally{setBusy(false);}
  };
  const edit = r => {
    setEditing(r._id);
    setForm({date:new Date(r.date).toLocaleDateString('en-CA'),machine:r.machine,employee:r.employee,shift:r.shift,jobs:r.jobs.map(j=>({...j,_id:j._id}))});
    setPage('New Production Entry');
  };
  const remove = async id => {
    if(!confirm('Delete this complete production group? This cannot be undone.')) return;
    try { await request(`/productions/${id}`,{method:'DELETE'});setNotice('Production deleted');await load(); }
    catch(e){setNotice(e.message);}
  };
  const filtered = useMemo(()=>records.filter(r=>{
    const date=new Date(r.date).toISOString().slice(0,10);
    return (!filters.search || [r.machine,r.employee,r.shift,...r.jobs.flatMap(j=>[j.partDescription,j.partNumber,j.operation,j.otherRemark])].join(' ').toLowerCase().includes(filters.search.toLowerCase()))
      && (!filters.machine || r.machine.toLowerCase().includes(filters.machine.toLowerCase()))
      && (!filters.employee || r.employee.toLowerCase().includes(filters.employee.toLowerCase()))
      && (!filters.shift || r.shift===filters.shift)
      && (!filters.from || date>=filters.from) && (!filters.to || date<=filters.to);
  }),[records,filters]);
  const exportExcel = async () => {
    try { const r=await request('/export.xlsx');const blob=await r.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='VMC_Production_Master.xlsx';a.click();URL.revokeObjectURL(url); }
    catch(e){setNotice(e.message);}
  };
  const pages=[['Dashboard',Activity],['New Production Entry',Plus],['Production History',ClipboardList],['Reports',FileBarChart]];
  const field=(label,value,onChange,options=[],placeholder='Enter '+label)=> <label className="field"><span>{label}</span>{options.length?<input list={'list-'+label.replace(/\W/g,'')} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/>:<input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/ >}{options.length>0&&<datalist id={'list-'+label.replace(/\W/g,'')}>{options.map(v=><option key={v} value={v}/>)}</datalist>}</label>;
  if(!token) return <div className="login-wrap"><form className="login-card" onSubmit={doLogin}><div className="brand-mark"><Boxes size={26}/></div><p className="eyebrow">MANUFACTURING OPERATIONS</p><h1>VMC Production Tracker</h1><p className="muted">Sign in to manage production records</p><label className="field"><span>Username</span><input value={login.username} onChange={e=>setLogin({...login,username:e.target.value})} required/></label><label className="field"><span>Password</span><input type="password" value={login.password} onChange={e=>setLogin({...login,password:e.target.value})} required/></label>{notice&&<p className="notice">{notice}</p>}<button className="primary full" disabled={busy}>{busy?'Signing in…':'Sign in'}</button><small>Initial credentials are configured by the server administrator.</small></form></div>;
  return <div className="app-shell"><aside className="sidebar"><div className="brand"><div className="brand-mark"><Boxes/></div><div><b>VMC TRACKER</b><small>Production Management</small></div></div><div className="nav-label">WORKSPACE</div>{pages.map(([p,Icon])=><button key={p} className={'nav-item '+(page===p?'active':'')} onClick={()=>{setPage(p);setNotice('');}}><Icon size={18}/>{p}</button>)}<div className="sidebar-bottom"><div className="user-chip"><div className="avatar">{username.slice(0,1).toUpperCase()}</div><div><b>{username}</b><small>Administrator</small></div></div><button className="nav-item" onClick={logout}><LogOut size={18}/>Sign out</button></div></aside>
  <main className="main"><header className="topbar"><div><span className="eyebrow">FACTORY OPERATIONS</span><h2>{page}</h2></div><button className="icon-btn" onClick={load} title="Refresh"><RefreshCw size={18}/></button></header>
  {notice&&<div className="notice">{notice}<button onClick={()=>setNotice('')}>×</button></div>}
  {page==='Dashboard'&&<><div className="welcome"><div><h1>Production overview</h1><p>Live summary of saved production records.</p></div><button className="primary" onClick={()=>{setForm(blank());setEditing(null);setPage('New Production Entry')}}><Plus size={17}/> New entry</button></div><div className="stats-grid"><Stat icon={ClipboardList} label="Production Groups" value={stats.groups??0}/><Stat icon={CheckCircle2} label="Total OK Quantity" value={Number(stats.okQty||0).toLocaleString()}/><Stat icon={CalendarDays} label="Production Dates" value={stats.dates??0}/><Stat icon={Boxes} label="Machines Used" value={stats.machines??0}/><Stat icon={Users} label="Employees" value={stats.employees??0}/><Stat icon={Activity} label="Job Entries" value={stats.jobs??0}/></div><section className="panel"><div className="panel-head"><div><h3>Recent production groups</h3><p>Latest saved records</p></div><button className="text-btn" onClick={()=>setPage('Production History')}>View history →</button></div><RecordTable rows={records.slice(0,6)} onEdit={edit} onDelete={remove}/></section></>}
  {page==='New Production Entry'&&<section className="panel"><div className="panel-head"><div><h3>{editing?'Edit production group':'New production entry'}</h3><p>Group details are entered once; add one or more jobs below.</p></div></div><form onSubmit={save}><div className="form-grid"><label className="field"><span>Date</span><input type="date" value={form.date} onChange={e=>setGroup('date',e.target.value)} required/></label>{field('Machine Number',form.machine,v=>setGroup('machine',v),suggestions.machines)}{field('Employee Name',form.employee,v=>setGroup('employee',v),suggestions.employees)}<label className="field"><span>Shift</span><select value={form.shift} onChange={e=>setGroup('shift',e.target.value)}><option>1st Shift</option><option>2nd Shift</option><option>3rd Shift</option><option>General</option></select></label></div><div className="jobs-head"><div><h3>Job details</h3><p>Each job is exported as a separate Excel row.</p></div><button type="button" className="secondary" onClick={()=>setForm(f=>({...f,jobs:[...f.jobs,emptyJob()]}))}><Plus size={16}/> Add Job</button></div>{form.jobs.map((j,i)=><div className="job-card" key={j._id||i}><div className="job-title"><b>Job {i+1}</b>{form.jobs.length>1&&<button type="button" className="danger-icon" onClick={()=>setForm(f=>({...f,jobs:f.jobs.filter((_,n)=>n!==i)}))}><Trash2 size={16}/></button>}</div><div className="form-grid">{field('Part Description',j.partDescription,v=>setJob(i,'partDescription',v),suggestions.partDescriptions)}{field('Part Number',j.partNumber,v=>setJob(i,'partNumber',v),suggestions.partNumbers)}<label className="field"><span>Start Time</span><input type="time" value={j.startTime} onChange={e=>setJob(i,'startTime',e.target.value)} required/></label><label className="field"><span>End Time</span><input type="time" value={j.endTime} onChange={e=>setJob(i,'endTime',e.target.value)} required/></label><label className="field"><span>OK Quantity</span><input type="number" min="0" step="1" value={j.okQty} onChange={e=>setJob(i,'okQty',e.target.value)} required/></label><label className="field"><span>Operation</span><input value={j.operation} onChange={e=>setJob(i,'operation',e.target.value)} placeholder="Enter operation"/></label><label className="field wide"><span>Other Remarks</span><input value={j.otherRemark} onChange={e=>setJob(i,'otherRemark',e.target.value)} placeholder="Optional remarks"/></label></div></div>)}<div className="form-actions"><button type="button" className="secondary" onClick={()=>{setForm(blank());setEditing(null)}}>Clear form</button><button className="primary" disabled={busy}>{busy?'Saving…':editing?'Update Production':'Save Production'}</button></div></form></section>}
  {page==='Production History'&&<section className="panel"><div className="panel-head"><div><h3>Production history</h3><p>{filtered.length} matching groups</p></div><button className="secondary" onClick={exportExcel}><Download size={16}/> Export Excel</button></div><FilterBar filters={filters} setFilters={setFilters}/><RecordTable rows={filtered} onEdit={edit} onDelete={remove}/></section>}
  {page==='Reports'&&<section className="panel"><div className="panel-head"><div><h3>Production reports</h3><p>Filter records and export the matching production data.</p></div><button className="primary" onClick={exportExcel}><Download size={16}/> Download Master Excel</button></div><FilterBar filters={filters} setFilters={setFilters}/><div className="report-summary"><div><span>Groups</span><b>{filtered.length}</b></div><div><span>Jobs</span><b>{filtered.reduce((n,r)=>n+r.jobs.length,0)}</b></div><div><span>OK Quantity</span><b>{filtered.reduce((n,r)=>n+r.jobs.reduce((s,j)=>s+Number(j.okQty||0),0),0).toLocaleString()}</b></div></div><RecordTable rows={filtered} onEdit={edit} onDelete={remove}/></section>}
  <footer>VMC Production Tracker <span>•</span> Production record management</footer></main></div>;
}
function Stat({icon:Icon,label,value}){return <div className="stat-card"><div className="stat-icon"><Icon size={19}/></div><span>{label}</span><b>{value}</b></div>}
function FilterBar({filters,setFilters}){const update=(k,v)=>setFilters(f=>({...f,[k]:v}));return <div className="filters"><label className="search-box"><Search size={17}/><input placeholder="Search machine, employee, part…" value={filters.search} onChange={e=>update('search',e.target.value)}/></label><input placeholder="Machine" value={filters.machine} onChange={e=>update('machine',e.target.value)}/><input placeholder="Employee" value={filters.employee} onChange={e=>update('employee',e.target.value)}/><select value={filters.shift} onChange={e=>update('shift',e.target.value)}><option value="">All shifts</option><option>1st Shift</option><option>2nd Shift</option><option>3rd Shift</option><option>General</option></select><input type="date" value={filters.from} onChange={e=>update('from',e.target.value)} title="From date"/><input type="date" value={filters.to} onChange={e=>update('to',e.target.value)} title="To date"/></div>}
function RecordTable({rows,onEdit,onDelete}){if(!rows.length)return <div className="empty">No production records found.</div>;return <div className="table-wrap"><table><thead><tr><th>Date</th><th>Machine</th><th>Employee</th><th>Shift</th><th>Jobs</th><th>OK Qty</th><th>Actions</th></tr></thead><tbody>{rows.map(r=><tr key={r._id}><td>{new Date(r.date).toLocaleDateString('en-IN')}</td><td><b>{r.machine}</b></td><td>{r.employee}</td><td>{r.shift}</td><td>{r.jobs.length}</td><td>{r.jobs.reduce((s,j)=>s+Number(j.okQty||0),0).toLocaleString()}</td><td><div className="actions"><button title="Edit" onClick={()=>onEdit(r)}><Pencil size={16}/></button><button title="Delete" onClick={()=>onDelete(r._id)}><Trash2 size={16}/></button></div></td></tr>)}</tbody></table></div>}
export default App;
